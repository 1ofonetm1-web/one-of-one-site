module.exports = {
  reactStrictMode: true,
};